from setuptools import setup
setup(name="Vectores y Areas"
      ,version="0.1",description="Prueba de paquetes distribuibles incluyendo todos los subpaquetes y paquetes"
      ,author="Fernando Rivera",author_email="fercho_212@hotmail.com"
      ,url="no may:c"
      ,packages=["vectores_areas","vectores_areas"])
